# Blank theme for Mautic

## This theme is managed centrally in https://github.com/mautic/mautic/blob/head/themes/blank and this is a read-only mirror repository.

**📣 Please make PRs and issues against Mautic Core, not here!**